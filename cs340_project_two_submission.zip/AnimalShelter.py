from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Connection Variables
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31197
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            try:
                result = self.collection.insert_one(data)
                if result.inserted_id:
                    return True
                else:
                    return False
            except Exception as e:
                print(f"An error occurred: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")


    # Read method to implement the R in CRUD.
    def read(self, query):
        try:
            results = self.collection.find(query)
            return [result for result in results]
        except Exception as e:
            print(f"An error occurred: {e}")
            return []

    # Update method to implement the U in CRUD
    def update(self, query, new_values):
        if query is not None and new_values is not None:
            try:
                result = self.collection.update_many(query, {'$set': new_values})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred during update: {e}")
                return 0
        else:
            raise Exception("Query and new_values parameters are required")

    # Delete method to implement the D in CRUD
    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred during deletion: {e}")
                return 0
        else:
            raise Exception("Query parameter is required")